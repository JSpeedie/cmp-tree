# Two Identical Directory Trees with a Subdirectory

The inputs of this test are two simple, identical directory trees. Each contain
the same 2 files (that are byte-for-byte identical) and nothing else. Both
directory trees contain a subdirectory with some files inside it.

The aim of this test is to serve as one of many tests that make sure `cmp-tree`:
1. Correctly recurses into subdirectories
2. Correctly identifies identical regular files as identical

`cmp-tree` should exit with an exit code of 0.

`diff -qr` should exit with an exit code of 0.
