# Only Differing Files in Simple Directory Trees

The inputs of this test are two directory trees with an identical file list,
but where every single file differs from its corresponding file in the other
directory tree.

The aim of this test is to serve as one of many tests that make sure `cmp-tree`:
1. Finds differences in the content of regular files

`cmp-tree` should exit with an exit code of 1.

`diff -qr` should exit with an exit code of 1.
