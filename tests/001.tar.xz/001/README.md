# Two Identical, Simple Directory Trees

The inputs of this test are two simple, identical directory trees. Each
directory tree contains the same 2 files (that are byte-for-byte identical) and
nothing else.

## Generating the Files for This Test

`[...]/Lorem.md` was made using Vim and copying the text from an online source.
`[...]/cmp_man_pages.txt` was made by running `man cmp > cmp_man_pages.txt`.

After generating the files, I copied them to the other directory via means I
have lost track of.

## The Aim of This Test

The aim of this test is to serve as one of many tests that make sure
`cmp-tree`:
1. Correctly identifies identical regular files as identical
2. Can correctly identify when files are identical in every way including their
   modification time.

## Expected Exit Codes

Ran from `tests/001`:

* `cmp-tree first/ second/` should exit with an exit code of 0.
* `cmp-tree -d first/ second/` should exit with an exit code of 0.
* `diff -qr first/ second/` should exit with an exit code of 0.
