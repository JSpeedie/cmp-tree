# Single Differing File in Simple Directory Trees

The inputs of this test are two simple, almost identical directory trees. Each
contain the same 2 files and nothing else, but one of the pairs of
corresponding files are not byte-for-byte identical and are in fact
significantly different.

The aim of this test is to serve as one of many tests that check if `cmp-tree`:
1. Correctly identifies identical regular files as identical

`cmp-tree` should exit with an exit code of 1.

`diff -qr` should exit with an exit code of 1.
