# 4 Level Trees Missing a Subdirectory

The inputs of this test are two partially similar directory trees where a
subdirectory in the first dir is completely absent. Instead, another
subdirectory, absent in the first directory, is present in the second
directory. This means that `cmp-tree` should not only note subdirectory that is
absent from the second directory, but that `cmp-tree` should note all the
contents of that subdir that are missing from the second directory, as well as
the same for the subdirectory present in the second directory but not the first
directory.

The aim of this test is to serve as one of many tests that make sure `cmp-tree`:
1. Correctly recurses into subdirectories
2. Correctly identifies missing directories

`cmp-tree` should exit with an exit code of 1.

`diff -qr` should exit with an exit code of 1.
