# 2 Level Trees Differing Soft Links that Point to Differing Directories

The inputs of this test are identical directory trees with corresponding soft
links that points to different paths (outside both input directory trees) which
are not identical. `cmp-tree` should evaluate the two soft links as being
different because they do not point to the same path, not because /what/ they
point to is identical.

`diff -qr` evaluates soft links as identical if /what/ they point to is
identical, so it will fail on this test case too although for different
reasons.

The aim of this test is to serve as one of many tests that make sure `cmp-tree`:
1. Correctly recurses into subdirectories
2. Correctly identifies differing soft links as differing

`cmp-tree` should exit with an exit code of 1.

`diff -qr` should exit with an exit code of 1.
