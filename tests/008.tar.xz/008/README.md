# 2 Level Trees Identical Soft Link that Points to Identical Directory

The inputs of this test are identical directory trees with a soft link that
points to a directory containing a regular file. The soft link in each
directory tree points to a path that is identical to the path the corresponding
soft link in the other directory points to. The directories pointed to by these
two soft links are also identical, but `cmp-tree` should evaluate two soft
links as being identical only if the path they point to is identical, not on
the condition that /what/ they point to is identical.

The aim of this test is to serve as one of many tests that make sure `cmp-tree`:
1. Correctly recurses into subdirectories
2. Correctly identifies identical soft links as identical

`cmp-tree` should exit with an exit code of 0.

`diff -qr` should exit with an exit code of 0.
