# Single Differing File in Directory Trees with a Subdirectory

The inputs of this test are two almost identical directory trees. Each contain
the same 2 files (that are byte-for-byte identical) as well as a subdirectory
which contains two files, one of which differs in its contents from its
corresponding file in the other directory tree.

The aim of this test is to serve as one of many tests that make sure `cmp-tree`:
1. Correctly recurses into subdirectories
2. Finds differences in the content of regular files

`cmp-tree` should exit with an exit code of 1.

`diff -qr` should exit with an exit code of 1.
