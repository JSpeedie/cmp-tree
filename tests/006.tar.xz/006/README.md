# Identical Directory Trees Containing Only Directories with 4 Levels of Subdirectories

The inputs of this test are two identical directory trees comprised solely of
directories. Both trees have 4 levels of subdirectories.

The aim of this test is to serve as one of many tests that make sure `cmp-tree`:
1. Correctly recurses into subdirectories
2. Correctly identifies identical directories as identical

`cmp-tree` should exit with an exit code of 0.

`diff -qr` should exit with an exit code of 0.
