# Two Differing Directory Trees with Files that Differ ONLY in Modification Time

The inputs of this test are two nearly identical directory trees. Each contain
the same 2 files (that are byte-for-byte identical), and the same subdirectory
that each contain the same 2 files (that are byte-for-byte identical) and
nothing else. All 4 corresponding regular files differ in their metadata,
specifically in their modification time.

## Generating the Files for This Test

I originally copied `first/` and `second/` from test 003. The files in
`second/` had their modification times changed so that they would differ from
the modification times of the files in `first/` using the following command:

```
find second/ -type f | sort | xargs -L1 touch -d "1 day ago"
```

The `find` and `sort` command prints the relative paths to all regular files in
the `second/` directory, one path per line, sorted. The `xargs` command then
runs `touch -d "1 day ago" [filename]` on each line of input (that's what the
`-L1` flag ensures) which is just to say it runs the `touch` command on every
relative path returned by the previous commands.

## The Aim of This Test

The aim of this test is to serve as one of many tests that make sure
`cmp-tree`:
1. Correctly recurses into subdirectories
2. Can correctly identify when files are identical in every way except their
   modification time.

## Expected Exit Codes

Ran from `tests/011`:

* `cmp-tree first/ second/` should exit with an exit code of 0.
* `cmp-tree -d first/ second/` should exit with an exit code of 1.
* `diff -qr first/ second/` should exit with an exit code of 0.
